<?php 
/*
Plugin Name: Quilt Toolkit
Plugin URI: https://github.com/saifur703/Quilt-WP
Author: Saifur Rahman
Author URI: https://github.com/saifur703/
Description: Toolkit Plugin for Quilt Custom WP Theme.
Version: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: quilt-toolkit
Domain Path: /languages
*/
Kirki::add_config( 'quilt_config', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );

Kirki::add_panel( 'quilt_options', array(
    'priority'    => 10,
    'title'       => esc_html__( 'Quilt Options', 'quilt-toolkit' ),
    'description' => esc_html__( 'Quilt Options here', 'quilt-toolkit' ),
) );

Kirki::add_section( 'quilt_header', array(
    'title'          => esc_html__( 'Header Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Header Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_slider', array(
    'title'          => esc_html__( 'Slider Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Header Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_intro', array(
    'title'          => esc_html__( 'Intro Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Intro Section Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_story', array(
    'title'          => esc_html__( 'Our Story Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Our Story Section Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_story_logo', array(
    'title'          => esc_html__( 'Our Story Logo Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Our Story Logo Section Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_project_overview', array(
    'title'          => esc_html__( 'Project Overview Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Project Overview Section Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );
Kirki::add_section( 'quilt_our_works', array(
    'title'          => esc_html__( 'Our Works Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Our Works Section Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_mission_statement', array(
    'title'          => esc_html__( 'Mission Statement Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Mission Statement Sections Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );


Kirki::add_section( 'quilt_team', array(
    'title'          => esc_html__( 'Our Team Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Our Team Sections Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );


Kirki::add_section( 'quilt_get_in_touch', array(
    'title'          => esc_html__( 'Get in touch Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Get in touch Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_section( 'quilt_footer', array(
    'title'          => esc_html__( 'Footer Options', 'quilt-toolkit' ),
    'description'    => esc_html__( 'Footer Options here.', 'quilt-toolkit' ),
    'panel'          => 'quilt_options',
    'priority'       => 160,
) );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'quilt_header_btn_text',
	'label'    => esc_html__( 'Header Button', 'quilt-toolkit' ),
	'section'  => 'quilt_header',
	'default'  => esc_html__( 'Donate', 'quilt-toolkit' ),
	'priority' => 10,
] );
Kirki::add_field( 'quilt_config', [
	'type'        => 'link',
	'settings'    => 'quilt_header_btn_link',
	'label'       => esc_html__( 'Header Button Link', 'quilt-toolkit' ),
	'section'     => 'quilt_header',
	'default'     => '#',
] );
Kirki::add_field( 'quilt_config', [
	'type'        => 'select',
	'settings'    => 'quilt_header_btn_target',
	'label'       => esc_html__( 'Header Button Link', 'quilt-toolkit' ),
	'section'     => 'quilt_header',
	'placeholder' => esc_html__( 'Select an option...', 'quilt-toolkit' ),
	'priority'    => 10,
	'multiple'    => 0,
	'choices'     => [
		'_self' => esc_html__( '_self', 'quilt-toolkit' ),
		'_blank' => esc_html__( '_blank', 'quilt-toolkit' ),
    ],
    'default'       =>  '_self'
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'repeater',
	'label'       => esc_html__( 'Slider Options', 'quilt-toolkit' ),
	'section'     => 'quilt_slider',
	'priority'    => 10,
	'row_label' => [
		'type'  => 'text',
		'value' => esc_html__( 'Slider item', 'quilt-toolkit' ),
	],
	'button_label' => esc_html__('Add New Slider', 'quilt-toolkit' ),
	'settings'     => 'quilt_welcome_slider',
	'fields' => [
		'slider_sub_title' => [
			'type'        => 'text',
			'label'       => esc_html__( 'Sub Title', 'quilt-toolkit' ),
		],
		'slider_title'  => [
			'type'        => 'text',
			'label'       => esc_html__( 'Title', 'quilt-toolkit' ),
		],
		'slider_bg'  => [
			'type'        => 'image',
            'label'       => esc_html__( 'Slider Background Image', 'quilt-toolkit' ),
            'default'       =>  '',
		],
	]
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'editor',
	'settings' => 'intro_text',
	'label'    => esc_html__( 'Intro Text', 'quilt-toolkit' ),
	'section'  => 'quilt_intro',
	'default'	=>	'<p>The Great Quilt Project is making a difference, and it makes us very proud to be able to support this fine work in these communities. Several Cooperatives have been formed by women in these communities in order to promote the life changing work being created here. Our model links the good people of these communities who wish to make a good living with quilting teachers and quilting companies who wish to help teach and supply these fine studios.</p>',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'background',
	'settings'    => 'intro_bg',
	'label'       => esc_html__( 'Background Color', 'quilt-toolkit' ),
	'section'     => 'quilt_intro',
	'default'     => [
		'background-color'      => '#f4ece6',
	],
	'output'      => [
		[
			'element' => '.intro-area',
		],
	],
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'image',
	'settings'    => 'story_img',
	'label'       => esc_html__( 'Our Story Image', 'quilt-toolkit' ),
	'section'     => 'quilt_story',
	'default'     => '',
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'story_img_hover_title',
	'label'    => esc_html__( 'Our Story Image Hover Title', 'quilt-toolkit' ),
	'section'  => 'quilt_story',
	'default'  => esc_html__( 'Skillful Workers', 'quilt-toolkit' ),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'textarea',
	'settings' => 'story_img_hover_description',
	'label'    => esc_html__( 'Our Story Image Hover Description', 'quilt-toolkit' ),
	'section'  => 'quilt_story',
	'default'  => esc_html__( 'Amy & Jean creating a needle turn hand applique border on their quilts.', 'quilt-toolkit' ),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'story_title',
	'label'    => esc_html__( 'Our Story Title', 'quilt-toolkit' ),
	'section'  => 'quilt_story',
	'default'  => esc_html__( 'Our Story', 'quilt-toolkit' ),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'editor',
	'settings' => 'story_description',
	'label'    => esc_html__( 'Our Story Description', 'quilt-toolkit' ),
	'section'  => 'quilt_story',
	'default'  => esc_html__( 'The Great Quilt Project provides training, education, marketing and financial assistance from our sponsors to areas of the globe that would never have this kind of opportunity without its help. This proven match-up of ideas and money with hard working and dedicated workers found in these communities provides year round employment opportunities, where before there were none. It has provided an increase in the quality of life for these good people and their extended families.
	Our people are happy & grateful for the chance you give them to make a difference in their community & their lives.', 'quilt-toolkit' ),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'repeater',
	'label'       => esc_html__( 'Repeater Control', 'quilt-toolkit' ),
	'section'     => 'quilt_story_logo',
	'priority'    => 10,
	'row_label' => [
		'type'  => 'text',
		'value' => esc_html__( 'Our Story Logo', 'quilt-toolkit' ),
	],
	'button_label' => esc_html__('Add New Logo', 'quilt-toolkit' ),
	'settings'     => 'quilt_story_logos',
	'fields' => [
		'story_logo' => [
			'type'        => 'image',
			'label'       => esc_html__( 'Logo', 'quilt-toolkit' ),
		],
	]
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'project_overview_title',
	'label'    => esc_html__( 'Title', 'quilt-toolkit' ),
	'section'  => 'quilt_project_overview',
	'default'  =>	'Project Overview',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'textarea',
	'settings' => 'project_overview_description',
	'label'    => esc_html__( 'Description', 'quilt-toolkit' ),
	'section'  => 'quilt_project_overview',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'project_overview_btn_text',
	'label'    => esc_html__( 'Button Text', 'quilt-toolkit' ),
	'section'  => 'quilt_project_overview',
	'default'  =>	esc_html__('Join us make a difference', 'quilt-toolkit'),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'link',
	'settings' => 'project_overview_btn_link',
	'label'    => esc_html__( 'Button Link', 'quilt-toolkit' ),
	'section'  => 'quilt_project_overview',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'image',
	'settings' => 'project_overview_img',
	'label'    => esc_html__( 'Right Side Image', 'quilt-toolkit' ),
	'section'  => 'quilt_project_overview',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'background',
	'settings'    => 'project_overview_bg',
	'label'       => esc_html__( 'Background Color', 'quilt-toolkit' ),
	'section'     => 'quilt_project_overview',
	'default'     => [
		'background-color'      => '#fbc31f',
	],
	'output'      => [
		[
			'element' => '.project-overview-area',
		],
	],
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'our_works_section_title',
	'label'    => esc_html__( 'Section Title', 'quilt-toolkit' ),
	'section'  => 'quilt_our_works',
	'default'  =>	esc_html__('Our works', 'quilt-toolkit'),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'textarea',
	'settings' => 'our_works_section_title_desc',
	'label'    => esc_html__( 'Section Title Description', 'quilt-toolkit' ),
	'section'  => 'quilt_our_works',
	'default'  =>	esc_html__('The partners of The Great Quilt Projects are amazing people to work with.  They support our work by traveling to our villages and teaching us new patterns & techniques several times a year.  They help us source the best quality fabrics, and help us sell our works when they are completed.  They care about us and have pride in the quality of our works.', 'quilt-toolkit'),
	'priority' => 10,
] );
Kirki::add_field( 'quilt_config', [
	'type'        => 'repeater',
	'label'       => esc_html__( 'Gallery', 'quilt-toolkit' ),
	'section'     => 'quilt_our_works',
	'priority'    => 10,
	'row_label' => [
		'type'  => 'text',
		'value' => esc_html__( 'Gallery item', 'quilt-toolkit' ),
	],
	'button_label' => esc_html__('Add New Gallery', 'quilt-toolkit' ),
	'settings'     => 'our_works_gallery',
	'fields' => [
		'gallery_image' => [
			'type'        => 'image',
			'label'       => esc_html__( 'Gallery image', 'quilt-toolkit' ),
			'default'     => '',
		],
		'gallery_hover_title' => [
			'type'        => 'text',
			'label'       => esc_html__( 'Gallery hover title', 'quilt-toolkit' ),
			'default'     => '',
		],
		'gallery_hover_description' => [
			'type'        => 'textarea',
			'label'       => esc_html__( 'Gallery hover description', 'quilt-toolkit' ),
			'default'     => '',
		],
		'gallery_custom_class' => [
			'type'        => 'select',
			'label'       => esc_html__( 'Custom Class', 'quilt-toolkit' ),
			'default'     => 'small-bg',
			'placeholder' => esc_html__( 'Select a class...', 'quilt-toolkit' ),
			'choices'     => [
				'small-bg' => esc_html__( 'Small image', 'quilt-toolkit' ),
				'large-bg' => esc_html__( 'Large image', 'quilt-toolkit' ),
				'wide-bg' => esc_html__( 'Wide image', 'quilt-toolkit' ),
			],
		],
	]
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'mission_statement_section_title',
	'label'    => esc_html__( 'Section Title', 'quilt-toolkit' ),
	'section'  => 'quilt_mission_statement',
	'default'  =>	esc_html__('The Great Quilt Project’s Mission Statement', 'quilt-toolkit'),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'editor',
	'settings' => 'mission_statement_description',
	'label'    => esc_html__( 'Section Description', 'quilt-toolkit' ),
	'section'  => 'quilt_mission_statement',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'mission_statement_btn_text1',
	'label'    => esc_html__( 'Button 1 Text', 'quilt-toolkit' ),
	'section'  => 'quilt_mission_statement',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'link',
	'settings' => 'mission_statement_btn_link1',
	'label'    => esc_html__( 'Button 1 Link', 'quilt-toolkit' ),
	'section'  => 'quilt_mission_statement',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'mission_statement_btn_text2',
	'label'    => esc_html__( 'Button 2 Text', 'quilt-toolkit' ),
	'section'  => 'quilt_mission_statement',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'link',
	'settings' => 'mission_statement_btn_link2',
	'label'    => esc_html__( 'Button 2 Link', 'quilt-toolkit' ),
	'section'  => 'quilt_mission_statement',
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'background',
	'settings'    => 'mission_statement_bg',
	'label'       => esc_html__( 'Background image or Color', 'quilt-toolkit' ),
	'section'     => 'quilt_mission_statement',
	'default'     => [
		'background-color'      => '#263044',
	],
	'output'      => [
		[
			'element' => '.mission-area',
		],
	],
] );


Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'team_section_title',
	'label'    => esc_html__( 'Section Title', 'quilt-toolkit' ),
	'section'  => 'quilt_team',
	'default'  =>	esc_html__('Our team', 'quilt-toolkit'),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'repeater',
	'label'       => esc_html__( 'Our Team', 'quilt-toolkit' ),
	'section'     => 'quilt_team',
	'priority'    => 10,
	'row_label' => [
		'type'  => 'text',
		'value' => esc_html__( 'Single Team', 'quilt-toolkit' ),
	],
	'button_label' => esc_html__('Add New Team', 'quilt-toolkit' ),
	'settings'     => 'single_team',
	'fields' => [
		'image' => [
			'type'        => 'image',
			'label'       => esc_html__( 'Team image', 'quilt-toolkit' ),
		],
		'name' => [
			'type'        => 'text',
			'label'       => esc_html__( 'Team Name', 'quilt-toolkit' ),
		],
	]
] );
Kirki::add_field( 'quilt_config', [
	'type'        => 'background',
	'settings'    => 'team_bg',
	'label'       => esc_html__( 'Background image or Color', 'quilt-toolkit' ),
	'section'     => 'quilt_team',
	'default'     => [
		'background-color'      => '#f3ede7',
	],
	'output'      => [
		[
			'element' => '.team-area',
		],
	],
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'left_title',
	'label'    => esc_html__( 'Section Left Title', 'quilt-toolkit' ),
	'section'  => 'quilt_get_in_touch',
	'default'  =>	esc_html__('Some Facts', 'quilt-toolkit'),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'        => 'repeater',
	'label'       => esc_html__( 'Facts', 'quilt-toolkit' ),
	'section'     => 'quilt_get_in_touch',
	'priority'    => 10,
	'row_label' => [
		'type'  => 'text',
		'value' => esc_html__( 'Single Fact', 'quilt-toolkit' ),
	],
	'button_label' => esc_html__('Add New Fact', 'quilt-toolkit' ),
	'settings'     => 'contact_fact',
	'fields' => [
		'fact_number'  => [
			'type'        => 'number',
			'label'       => esc_html__( 'Fact Number', 'quilt-toolkit' ),
		],
		'fact_description'  => [
			'type'        => 'textarea',
			'label'       => esc_html__( 'Fact Description', 'quilt-toolkit' ),
		],
		'fact_icon' => [
			'type'     => 'image',
			'label'    => esc_html__( 'icon Control', 'quilt-toolkit' ),
		],
	]
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'contact_form_title',
	'label'    => esc_html__( 'Contact Form Title', 'quilt-toolkit' ),
	'section'  => 'quilt_get_in_touch',
	'default'  =>	esc_html__('Get in touch', 'quilt-toolkit'),
	'priority' => 10,
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'code',
	'settings' => 'contact_form',
	'label'    => esc_html__( 'Contact Form Shortcode', 'quilt-toolkit' ),
	'section'  => 'quilt_get_in_touch',
	'default'  =>	esc_html__('[contact-form-7 id="162" title="Get in Touch"]', 'quilt-toolkit'),
	'priority' => 10,
] );


Kirki::add_field( 'quilt_config', [
	'type'     => 'image',
	'settings' => 'footer_logo',
	'label'    => esc_html__( 'Footer Logo', 'quilt-toolkit' ),
	'section'  => 'quilt_footer',
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'footer_copyright',
	'label'    => esc_html__( 'Copyright Text', 'quilt-toolkit' ),
	'default'  =>	esc_html__('Copyright © 2020 The Great Quilt Project. All Rights Reserved.', 'quilt-toolkit'),
	'section'  => 'quilt_footer',
] );


Kirki::add_field( 'quilt_config', [
	'type'        => 'repeater',
	'label'       => esc_html__( 'Social Links', 'quilt-toolkit' ),
	'section'     => 'quilt_footer',
	'priority'    => 10,
	'row_label' => [
		'type'  => 'text',
		'value' => esc_html__( 'Social Link', 'quilt-toolkit' ),
	],
	'button_label' => esc_html__('Add New Social Link', 'quilt-toolkit' ),
	'settings'     => 'social_links',
	'fields' => [
		'facebook'  => [
			'type'        => 'url',
			'label'       => esc_html__( 'Facebook', 'quilt-toolkit' ),
		],
		'twitter'  => [
			'type'        => 'url',
			'label'       => esc_html__( 'Twitter', 'quilt-toolkit' ),
		],
		'linkedin'  => [
			'type'        => 'url',
			'label'       => esc_html__( 'LinkedIn', 'quilt-toolkit' ),
		],
		'instagram'  => [
			'type'        => 'url',
			'label'       => esc_html__( 'Instagram', 'quilt-toolkit' ),
		],
	]
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'footer_contact_title',
	'label'    => esc_html__( 'Quick Contact Title', 'quilt-toolkit' ),
	'default'  =>	esc_html__('Quick Contact', 'quilt-toolkit'),
	'section'  => 'quilt_footer',
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'textarea',
	'settings' => 'footer_contact_text',
	'label'    => esc_html__( 'Quick Contact Text', 'quilt-toolkit' ),
	'section'  => 'quilt_footer',
] );

Kirki::add_field( 'quilt_config', [
	'type'     => 'text',
	'settings' => 'footer_telephone',
	'label'    => esc_html__( 'Phone Number', 'quilt-toolkit' ),
	'section'  => 'quilt_footer',
] );