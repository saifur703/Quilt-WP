<?php 

// Silence is golden.